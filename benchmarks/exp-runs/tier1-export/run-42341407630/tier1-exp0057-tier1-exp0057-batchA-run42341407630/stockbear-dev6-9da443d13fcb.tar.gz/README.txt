StockBear v0.1.0-dev6 Tier-1 candidate package.
The extracted ./stockbear is the EXACT binary used in this job's matches.
Verify with: sha256sum -c SHA256SUMS.txt
